# 第三方预设来源与许可声明

Phos 本体以 **MIT License** 开源；本安装器自身脚本同样遵循 **MIT License**。
以下胶片模拟预设均由本安装器在用户本机从原作者公开渠道实时下载，**不随 Phos 应用程序或本安装包再分发**；使用对应 LUT 文件时请遵守原作者各自的授权协议：

| 预设分组 | 原作者 / 项目 | 许可协议 | 官方上游地址 |
|---|---|---|---|
| RawTherapee 胶片与拍立得（18 款） | Pat David, Pavlov Dmitry, Michael Ezra 等 | **CC BY-SA 4.0** | https://rawtherapee.com/shared/HaldCLUT.zip |
| 富士 X-Trans III（5 款） | Stuart Sowerby | 社区免费发布（保留原作者署名与出处） | https://blog.sowerby.me/fuji-film-simulation-profiles/ |
| 富士 X-Trans IV sRGB 转换（3 款） | abpy (`FujifilmCameraProfiles`) | **CC BY-NC-SA 4.0**（非商业使用） | https://github.com/abpy/FujifilmCameraProfiles |
| Kodak 2383 D65 / Fuji 3513DI D65（2 款 sRGB 适配） | imnz730 (`LUTs`) + VFX IO 1D Shaper | 社区开源仓库（由脚本本机重采样导出） | https://github.com/imnz730/LUTs |
| PictureFX GoldFX Spring Breeze & CineStill 800T v2（2 款） | Marc Roovers (`PictureFX` / G'MIC) | 作者免费发布（保留原作者署名与出处） | https://gmic.eu/color_presets/picturefx_sample_1.html |
| IWLTBAP 免费调色包（4 款） | IWLTBAP SAS (`LUTs Color Grading Pack Free`) | **Freeware**（免费用于个人与商业调色；禁止转售、共享或再分发预设文件） | https://luts.iwltbap.com/ |

如仅希望安装可用于商业用途且无需顾虑 `IWLTBAP` 再分发条款的条目，可运行：

```bash
python3 install_luts.py --skip-iwltbap
```

并在涉及 `CC BY-NC-SA 4.0` 时自行移除 `02_富士模拟/Fuji XTrans IV - * (sRGB).cube`。
