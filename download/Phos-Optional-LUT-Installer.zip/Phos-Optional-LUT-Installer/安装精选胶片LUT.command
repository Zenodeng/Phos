#!/bin/bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# 寻找可用的 Python 3（macOS Xcode CLT / python.org / Homebrew 均可）
PY=""
for cand in \
  "$(command -v python3 2>/dev/null || true)" \
  "/Library/Frameworks/Python.framework/Versions/Current/bin/python3" \
  "/opt/homebrew/bin/python3" \
  "/usr/local/bin/python3" \
  "/usr/bin/python3"
do
  if [[ -n "$cand" && -x "$cand" ]] && "$cand" -c "import sys" >/dev/null 2>&1; then
    PY="$cand"
    break
  fi
done

if [[ -z "$PY" ]]; then
  echo "未检测到可直接运行的 Python 3。"
  echo "请先在终端运行 xcode-select --install，或前往 https://www.python.org/downloads/macos/ 安装后再双击本脚本。"
  echo
  read -r -p "按回车键退出..."
  exit 1
fi

set +e
"$PY" "$DIR/install_luts.py" "$@"
STATUS=$?
set -e

echo
read -r -p "按回车键关闭窗口..."
exit "$STATUS"
