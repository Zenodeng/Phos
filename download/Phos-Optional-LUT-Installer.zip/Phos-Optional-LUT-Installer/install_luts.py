#!/usr/bin/env python3
"""
Phos 可选精选胶片 LUT 安装器（纯 Python 标准库，无第三方依赖）。

特点：
1. 安装包自身不含第三方受版权限制的二进制 LUT 文件，全部从原作者官方公开地址实时拉取。
2. 对体积较大的官方合集包（如 RawTherapee 421 MB、IWLTBAP 61 MB）自动使用 HTTP Range 分片读取，
   仅下载精选的那几十个文件（总流量约 30–40 MB），节省时间与带宽。
3. 现场通过 sRGB -> Linear -> Cineon Log 1D Shaper 重采样 imnz730 Kodak 2383 / Fujifilm 3513DI，
   输出可直接作用于 sRGB/Rec.709 照片的 33³ `.cube` 文件，不会产生直套 Cineon LUT 时的压暗死黑问题。
4. 默认安全保护用户现有目录：交互式运行会询问「备份旧目录并重整分类（保留 我的LUT）」还是「仅补充写入」。
"""

from __future__ import annotations

import argparse
import hashlib
import io
import math
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
import zipfile
from typing import Callable, Dict, Iterable, List, Optional, Tuple


USER_AGENT = "Phos-Optional-LUT-Installer/1.0 (+https://zenodeng.com)"
DEFAULT_DEST = os.path.expanduser("~/Documents/RawTherapee/HaldCLUT")

URL_RAWTHERAPEE_ZIP = "https://rawtherapee.com/shared/HaldCLUT.zip"
URL_SOWERBY_ZIP = "https://blog.sowerby.me/LUTs/Fujifilm-XTrans-III.zip"
URL_IWLTBAP_ZIP = (
    "https://luts.iwltbap.com/free/LUTs_Color_Grading_Pack_(Free)_by_IWLTBAP.zip"
)
URL_ABPY_BASE = (
    "https://raw.githubusercontent.com/abpy/FujifilmCameraProfiles/master/"
    "provia%20conversion%20luts/"
)
URL_IMNZ_BASE = "https://raw.githubusercontent.com/imnz730/LUTs/master/"
URL_PICTUREFX_SPRING = (
    "https://gmic.eu/color_presets/picturefx/clut/goldfx_spring_breeze.png"
)
URL_PICTUREFX_800T = (
    "https://drive.google.com/uc?export=download&id=1wcHcKKY2AW6vK-2i5MuB1OJglQ-qU6yw"
)


# 每个条目的结构：(目标相对路径, 风格简注)
RAWTHERAPEE_ITEMS: List[Tuple[str, str]] = [
    ("常用推荐/Agfa Vista 200.png", "HaldCLUT/Color/Agfa/Agfa Vista 200.png"),
    ("常用推荐/Fuji 400H 2.png", "HaldCLUT/Color/Fuji/Fuji 400H 2.png"),
    ("常用推荐/Fuji Superia 400 2.png", "HaldCLUT/Color/Fuji/Fuji Superia 400 2.png"),
    ("常用推荐/Ilford HP5 2.png", "HaldCLUT/Black-and-White/Ilford/Ilford HP5 2.png"),
    ("常用推荐/Kodak Ektar 100.png", "HaldCLUT/Color/Kodak/Kodak Ektar 100.png"),
    ("常用推荐/Kodak Kodachrome 64.png", "HaldCLUT/Color/Kodak/Kodak Kodachrome 64.png"),
    ("常用推荐/Kodak Portra 400 2.png", "HaldCLUT/Color/Kodak/Kodak Portra 400 2.png"),
    ("常用推荐/Kodak T-Max 400.png", "HaldCLUT/Black-and-White/Kodak/Kodak T-Max 400.png"),
    ("01_日常与经典胶片/Kodak Portra 160 2.png", "HaldCLUT/Color/Kodak/Kodak Portra 160 2.png"),
    ("01_日常与经典胶片/Kodak Portra 400 NC 2.png", "HaldCLUT/Color/Kodak/Kodak Portra 400 NC 2.png"),
    ("01_日常与经典胶片/Kodak Portra 800 2.png", "HaldCLUT/Color/Kodak/Kodak Portra 800 2.png"),
    ("01_日常与经典胶片/Fuji Provia 100F.png", "HaldCLUT/Color/Fuji/Fuji Provia 100F.png"),
    ("01_日常与经典胶片/Fuji Velvia 50.png", "HaldCLUT/Color/Fuji/Fuji Velvia 50.png"),
    ("03_电影感与印片/TealOrange2.png", "HaldCLUT/Color/CreativePack-1/TealOrange2.png"),
    ("03_电影感与印片/BleachBypass2.png", "HaldCLUT/Color/CreativePack-1/BleachBypass2.png"),
    ("03_电影感与印片/DropBlues.png", "HaldCLUT/Color/CreativePack-1/DropBlues.png"),
    ("04_拍立得复古/Polaroid 690 3.png", "HaldCLUT/Color/Polaroid/Polaroid 690 3.png"),
    ("04_拍立得复古/Polaroid PX-70 3.png", "HaldCLUT/Color/Polaroid/Polaroid PX-70 3.png"),
]

SOWERBY_ITEMS: List[Tuple[str, str]] = [
    ("02_富士模拟/Fuji XTrans III - Classic Chrome.png", "Fuji XTrans III - Classic Chrome.png"),
    ("02_富士模拟/Fuji XTrans III - Pro Neg Hi.png", "Fuji XTrans III - Pro Neg Hi.png"),
    ("02_富士模拟/Fuji XTrans III - Velvia.png", "Fuji XTrans III - Velvia.png"),
    ("02_富士模拟/Fuji XTrans III - Acros.png", "Fuji XTrans III - Acros.png"),
    ("02_富士模拟/Fuji XTrans III - Acros+Ye.png", "Fuji XTrans III - Acros+Ye.png"),
]

ABPY_ITEMS: List[Tuple[str, str]] = [
    ("02_富士模拟/Fuji XTrans IV - Classic Neg (sRGB).cube", "Provia%20to%20Classic%20Neg%20sRGB.cube"),
    ("02_富士模拟/Fuji XTrans IV - Nostalgic Neg (sRGB).cube", "Provia%20to%20Nostalgic%20Neg%20sRGB.cube"),
    ("02_富士模拟/Fuji XTrans IV - Bleach Bypass (sRGB).cube", "Provia%20to%20Bleach%20Bypass%20sRGB.cube"),
]

IWLTBAP_ITEMS: List[Tuple[str, str]] = [
    ("03_电影感与印片/IWLTBAP F-8700-V2-STD.cube", "01 - Standard/F-8700-V2-STD.cube"),
    ("03_电影感与印片/IWLTBAP Aspen - Standard.cube", "08 - Bonus/Aspen/IWLTBAP Aspen - Standard.cube"),
    ("03_电影感与印片/IWLTBAP Sedona - Standard.cube", "08 - Bonus/Sedona/IWLTBAP Sedona - Standard.cube"),
    ("03_电影感与印片/IWLTBAP Humble - Standard.cube", "08 - Bonus/Humble/IWLTBAP Humble - Standard.cube"),
]


def http_open(url: str, headers: Optional[Dict[str, str]] = None, method: str = "GET", timeout: int = 45):
    req_headers = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers, method=method)
    return urllib.request.urlopen(req, timeout=timeout)


def download_bytes(url: str, retries: int = 3, timeout: int = 60) -> bytes:
    last_err: Optional[Exception] = None
    for attempt in range(1, retries + 1):
        try:
            with http_open(url, timeout=timeout) as resp:
                return resp.read()
        except Exception as err:
            last_err = err
            if attempt < retries:
                time.sleep(1.5 * attempt)
    raise RuntimeError(f"下载失败 ({url}): {last_err}")


class HttpRangeRaw(io.RawIOBase):
    """通过 HTTP Range 按需读取远程大型 ZIP，只下载中央目录及所需条目片段。"""

    def __init__(self, url: str, length: int):
        self.url = url
        self.length = length
        self.pos = 0
        self.tail_size = min(length, 256 * 1024)
        self.tail_start = length - self.tail_size
        self.tail_data = self._fetch(self.tail_start, length - 1)

    def _fetch(self, start: int, end: int) -> bytes:
        last_err: Optional[Exception] = None
        for attempt in range(1, 4):
            try:
                with http_open(self.url, headers={"Range": f"bytes={start}-{end}"}, timeout=45) as r:
                    return r.read()
            except Exception as err:
                last_err = err
                if attempt < 3:
                    time.sleep(1.2 * attempt)
        raise RuntimeError(f"分片请求失败 ({self.url} {start}-{end}): {last_err}")

    def seekable(self) -> bool:
        return True

    def readable(self) -> bool:
        return True

    def tell(self) -> int:
        return self.pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if whence == io.SEEK_SET:
            self.pos = offset
        elif whence == io.SEEK_CUR:
            self.pos += offset
        elif whence == io.SEEK_END:
            self.pos = self.length + offset
        else:
            raise ValueError(f"不支持的 whence: {whence}")
        if self.pos < 0:
            self.pos = 0
        return self.pos

    def readinto(self, b) -> int:
        if self.pos >= self.length:
            return 0
        want = min(len(b), self.length - self.pos)
        if want == 0:
            return 0
        if self.pos >= self.tail_start:
            s = self.pos - self.tail_start
            chunk = self.tail_data[s : s + want]
        else:
            chunk = self._fetch(self.pos, self.pos + want - 1)
        got = len(chunk)
        b[:got] = chunk
        self.pos += got
        return got


def open_remote_zip(url: str) -> Tuple[zipfile.ZipFile, Optional[io.BufferedReader], bool]:
    """优先用 HTTP Range 打开远程 ZIP，若服务器不支持则退回完整下载。"""
    try:
        with http_open(url, headers={"Range": "bytes=0-15"}, timeout=20) as r:
            status = getattr(r, "status", 200)
            cr = r.headers.get("Content-Range", "")
            if status == 206 and "/" in cr:
                total_len = int(cr.rsplit("/", 1)[1])
                raw = HttpRangeRaw(url, total_len)
                buf = io.BufferedReader(raw, buffer_size=512 * 1024)
                return zipfile.ZipFile(buf), buf, True
    except Exception:
        pass
    data = download_bytes(url, timeout=180)
    return zipfile.ZipFile(io.BytesIO(data)), None, False


def validate_png(data: bytes, name: str) -> None:
    if not data.startswith(b"\x89PNG\r\n\x1a\n") or len(data) < 1024:
        raise ValueError(f"PNG 校验失败（可能未拿到有效图像）: {name}")


def parse_cube_3d(text: str, name: str) -> Tuple[int, List[Tuple[float, float, float]]]:
    size = None
    pts: List[Tuple[float, float, float]] = []
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        upper = line.upper()
        if upper.startswith(("TITLE", "DOMAIN_MIN", "DOMAIN_MAX", "LUT_1D_", "LUT_3D_INPUT_RANGE")):
            if upper.startswith("LUT_3D_SIZE"):
                size = int(line.split()[-1])
            continue
        if upper.startswith("LUT_3D_SIZE"):
            size = int(line.split()[-1])
            continue
        parts = line.split()
        if len(parts) == 3:
            pts.append((float(parts[0]), float(parts[1]), float(parts[2])))
    if not size or len(pts) != size ** 3:
        raise ValueError(f".cube 校验失败 ({name}): 声明维度={size}, 实际点数={len(pts)}")
    return size, pts


def parse_cube_1d(text: str, name: str) -> Tuple[List[float], float, float]:
    size = None
    rmin, rmax = 0.0, 1.0
    pts: List[float] = []
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        upper = line.upper()
        if upper.startswith("LUT_1D_SIZE"):
            size = int(line.split()[-1])
            continue
        if upper.startswith("LUT_1D_INPUT_RANGE"):
            sp = line.split()
            rmin, rmax = float(sp[1]), float(sp[2])
            continue
        if upper.startswith(("TITLE", "DOMAIN_")):
            continue
        parts = line.split()
        if len(parts) == 3:
            pts.append(float(parts[0]))
    if not size or len(pts) != size:
        raise ValueError(f"1D .cube 校验失败 ({name}): 声明={size}, 实际={len(pts)}")
    return pts, rmin, rmax


def validate_cube_bytes(data: bytes, name: str) -> None:
    text = data.decode("utf-8", errors="replace")
    if "LUT_3D_SIZE" not in text:
        raise ValueError(f".cube 校验失败（缺少 LUT_3D_SIZE，可能被拦截为网页）: {name}")
    parse_cube_3d(text, name)


def eval_1d(x: float, table: List[float], rmin: float, rmax: float) -> float:
    span = rmax - rmin if rmax != rmin else 1.0
    u = (x - rmin) / span
    if u < 0.0:
        u = 0.0
    elif u > 1.0:
        u = 1.0
    t = u * (len(table) - 1)
    i0 = int(math.floor(t))
    i1 = i0 + 1 if i0 + 1 < len(table) else i0
    f = t - i0
    return table[i0] * (1.0 - f) + table[i1] * f


def trilinear_3d(
    r: float, g: float, b: float, table: List[Tuple[float, float, float]], n: int
) -> Tuple[float, float, float]:
    def clamp01(v: float) -> float:
        return 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)

    nm1 = n - 1
    cr = clamp01(r) * nm1
    cg = clamp01(g) * nm1
    cb = clamp01(b) * nm1
    r0 = int(cr)
    g0 = int(cg)
    b0 = int(cb)
    r1 = r0 + 1 if r0 < nm1 else nm1
    g1 = g0 + 1 if g0 < nm1 else nm1
    b1 = b0 + 1 if b0 < nm1 else nm1
    fr = cr - r0
    fg = cg - g0
    fb = cb - b0
    fr0, fg0, fb0 = 1.0 - fr, 1.0 - fg, 1.0 - fb

    n2 = n * n
    c000 = table[r0 + g0 * n + b0 * n2]
    c100 = table[r1 + g0 * n + b0 * n2]
    c010 = table[r0 + g1 * n + b0 * n2]
    c110 = table[r1 + g1 * n + b0 * n2]
    c001 = table[r0 + g0 * n + b1 * n2]
    c101 = table[r1 + g0 * n + b1 * n2]
    c011 = table[r0 + g1 * n + b1 * n2]
    c111 = table[r1 + g1 * n + b1 * n2]

    w000 = fr0 * fg0 * fb0
    w100 = fr * fg0 * fb0
    w010 = fr0 * fg * fb0
    w110 = fr * fg * fb0
    w001 = fr0 * fg0 * fb
    w101 = fr * fg0 * fb
    w011 = fr0 * fg * fb
    w111 = fr * fg * fb

    or_ = clamp01(
        c000[0] * w000 + c100[0] * w100 + c010[0] * w010 + c110[0] * w110
        + c001[0] * w001 + c101[0] * w101 + c011[0] * w011 + c111[0] * w111
    )
    og = clamp01(
        c000[1] * w000 + c100[1] * w100 + c010[1] * w010 + c110[1] * w110
        + c001[1] * w001 + c101[1] * w101 + c011[1] * w011 + c111[1] * w111
    )
    ob = clamp01(
        c000[2] * w000 + c100[2] * w100 + c010[2] * w010 + c110[2] * w110
        + c001[2] * w001 + c101[2] * w101 + c011[2] * w011 + c111[2] * w111
    )
    return or_, og, ob


def bake_srgb_cineon_film(
    s2l: Tuple[List[float], float, float],
    l2c: Tuple[List[float], float, float],
    film_text: str,
    title: str,
    out_n: int = 33,
) -> bytes:
    n_film, film_table = parse_cube_3d(film_text, title)
    t_s2l, s2l_min, s2l_max = s2l
    t_l2c, l2c_min, l2c_max = l2c
    # 预先构建每条通道的一维映射（一共只有 33 个刻度值），把三线性采样聚焦到 3D 查找本身
    axis_cin = [
        eval_1d(eval_1d(i / (out_n - 1.0), t_s2l, s2l_min, s2l_max), t_l2c, l2c_min, l2c_max)
        for i in range(out_n)
    ]
    lines = [
        f'TITLE "{title}"',
        "# Baked by Phos Optional LUT Installer: sRGB -> Linear -> Cineon Log -> Film Print LUT",
        f"LUT_3D_SIZE {out_n}",
        "DOMAIN_MIN 0.0 0.0 0.0",
        "DOMAIN_MAX 1.0 1.0 1.0",
    ]
    for b_idx in range(out_n):
        cb = axis_cin[b_idx]
        for g_idx in range(out_n):
            cg = axis_cin[g_idx]
            for r_idx in range(out_n):
                cr = axis_cin[r_idx]
                rr, gg, bb = trilinear_3d(cr, cg, cb, film_table, n_film)
                lines.append(f"{rr:.6f} {gg:.6f} {bb:.6f}")
    return ("\n".join(lines) + "\n").encode("utf-8")


def write_target_file(
    dest_root: str, rel_path: str, data: bytes, overwrite: bool
) -> str:
    full = os.path.join(dest_root, rel_path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    if os.path.exists(full) and not overwrite:
        return "skipped"
    with open(full, "wb") as f:
        f.write(data)
    return "written"


def inspect_existing_luts(dest_root: str) -> Tuple[int, bool]:
    """返回 (已有 LUT 文件数量, 是否存在用户我的LUT目录)。"""
    if not os.path.isdir(dest_root):
        return 0, False
    count = 0
    for dp, _, fns in os.walk(dest_root):
        for fn in fns:
            if not fn.startswith(".") and fn.lower().endswith((".png", ".tif", ".tiff", ".cube")):
                count += 1
    has_my_lut = os.path.isdir(os.path.join(dest_root, "我的LUT"))
    return count, has_my_lut


def decide_mode(dest_root: str, requested_mode: str) -> str:
    existing_count, _ = inspect_existing_luts(dest_root)
    if existing_count == 0:
        return "clean"
    if requested_mode in ("clean", "merge"):
        return requested_mode
    if not sys.stdin.isatty():
        return "merge"
    print("")
    print(f"检测到目标目录已存在 {existing_count} 个 LUT 文件：{dest_root}")
    print("请选择安装方式：")
    print("  [1] 先把旧目录完整备份到同级 HaldCLUT_备份_*，再装入整洁分类（会自动迁回「我的LUT」）")
    print("  [2] 保留现有目录结构与文件不动，仅补充缺少的精选 LUT（默认，直接回车）")
    ans = input("请输入 1 或 2 [默认 2]: ").strip()
    return "clean" if ans == "1" else "merge"


def prepare_clean_destination(dest_root: str) -> Optional[str]:
    existing_count, has_my_lut = inspect_existing_luts(dest_root)
    if not os.path.exists(dest_root):
        os.makedirs(dest_root, exist_ok=True)
        return None
    # 检查目录里是否有除了隐藏文件外的任何文件
    entries = [e for e in os.listdir(dest_root) if not e.startswith(".")]
    if not entries and existing_count == 0:
        return None
    stamp = time.strftime("%Y%m%d_%H%M%S")
    parent = os.path.dirname(os.path.abspath(dest_root))
    backup = os.path.join(parent, f"HaldCLUT_备份_{stamp}")
    shutil.move(dest_root, backup)
    os.makedirs(dest_root, exist_ok=True)
    if has_my_lut:
        shutil.copytree(os.path.join(backup, "我的LUT"), os.path.join(dest_root, "我的LUT"))
    return backup


def expected_rel_paths(skip_iwltbap: bool) -> List[str]:
    rels = (
        [r for r, _ in RAWTHERAPEE_ITEMS]
        + ["01_日常与经典胶片/PictureFX GoldFX Spring Breeze.png"]
        + [r for r, _ in SOWERBY_ITEMS]
        + [r for r, _ in ABPY_ITEMS]
        + [
            "03_电影感与印片/Kodak 2383 D65 (sRGB适配).cube",
            "03_电影感与印片/Fujifilm 3513DI D65 (sRGB适配).cube",
            "03_电影感与印片/PictureFX CineStill 800T v2.cube",
        ]
    )
    if not skip_iwltbap:
        rels += [r for r, _ in IWLTBAP_ITEMS]
    return rels


def write_licenses_notice(dest_root: str, include_iwltbap: bool) -> None:
    note = """Phos 精选胶片 LUT 第三方许可与来源说明
======================================

1. RawTherapee Film Simulation Collection (2015-09-20)
   - 涉及文件：常用推荐/ (8 款)、01_日常与经典胶片/ (Portra/Provia/Velvia)、03_电影感与印片/ (TealOrange2/BleachBypass2/DropBlues)、04_拍立得复古/ (2 款)
   - 许可协议：CC BY-SA 4.0
   - 上游地址：https://rawtherapee.com/shared/HaldCLUT.zip

2. Stuart Sowerby Fujifilm X-Trans III Film Simulations
   - 涉及文件：02_富士模拟/Fuji XTrans III - *.png (5 款)
   - 上游地址：https://blog.sowerby.me/fuji-film-simulation-profiles/

3. abpy FujifilmCameraProfiles (Provia -> X-Trans IV sRGB Conversion LUTs)
   - 涉及文件：02_富士模拟/Fuji XTrans IV - * (sRGB).cube (3 款)
   - 许可协议：CC BY-NC-SA 4.0（仅限非商业用途）
   - 上游地址：https://github.com/abpy/FujifilmCameraProfiles

4. imnz730 LUTs (sRGB -> Linear -> Cineon Log 现场适配版本)
   - 涉及文件：03_电影感与印片/Kodak 2383 D65 (sRGB适配).cube、Fujifilm 3513DI D65 (sRGB适配).cube
   - 上游地址：https://github.com/imnz730/LUTs

5. PictureFX (Marc Roovers)
   - 涉及文件：01_日常与经典胶片/PictureFX GoldFX Spring Breeze.png、03_电影感与印片/PictureFX CineStill 800T v2.cube
   - 上游地址：https://gmic.eu/color_presets/picturefx_sample_1.html 与作者公开 Google Drive 分享链接
"""
    if include_iwltbap:
        note += """
6. IWLTBAP Free LUTs Pack (由安装器从官方免费地址实时下载)
   - 涉及文件：03_电影感与印片/IWLTBAP *.cube (4 款)
   - 许可声明：Copyright IWLTBAP SAS，仅允许个人与商业调色使用，禁止再分发源文件。
   - 上游地址：https://luts.iwltbap.com/
"""
    with open(os.path.join(dest_root, "THIRD_PARTY_LICENSES.txt"), "w", encoding="utf-8") as f:
        f.write(note)


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="为 Phos 下载并安装精选 sRGB 胶片模拟 LUT 库。"
    )
    p.add_argument("--dest", default=DEFAULT_DEST, help=f"目标目录（默认：{DEFAULT_DEST}）")
    p.add_argument(
        "--mode",
        choices=("auto", "clean", "merge"),
        default="auto",
        help="安装模式：auto（交互询问）、clean（备份旧库后整洁重装）、merge（保留旧库仅追加）",
    )
    p.add_argument("--overwrite", action="store_true", help="merge 模式下也覆盖同名文件")
    p.add_argument(
        "--skip-iwltbap",
        action="store_true",
        help="跳过 IWLTBAP 免费电影预设（仅安装 30 款开源/社区胶片模拟）",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    dest_root = os.path.abspath(os.path.expanduser(args.dest))
    total_expected = 30 if args.skip_iwltbap else 34

    print("==========================================")
    print(f"Phos 可选精选胶片 LUT 安装器（共 {total_expected} 款）")
    print(f"目标目录：{dest_root}")
    print("==========================================")

    mode = decide_mode(dest_root, args.mode)
    overwrite = True if mode == "clean" else args.overwrite

    backup_dir: Optional[str] = None
    if mode == "clean":
        backup_dir = prepare_clean_destination(dest_root)
        if backup_dir:
            print(f"\n[备份] 原目录已无损归档至：{backup_dir}")
            if os.path.isdir(os.path.join(dest_root, "我的LUT")):
                print("[备份] 已保留您原有的「我的LUT」文件夹。")
    else:
        os.makedirs(dest_root, exist_ok=True)
        print("\n[模式] 保留原有文件不动，补充安装缺失条目。")

    stats = {"written": 0, "skipped": 0}

    def record(rel: str, data: bytes, validator: Optional[Callable[[bytes, str], None]] = None) -> None:
        if validator:
            validator(data, rel)
        res = write_target_file(dest_root, rel, data, overwrite=overwrite)
        stats[res] += 1
        mark = "写入" if res == "written" else "跳过(已存在)"
        print(f"  - [{mark}] {rel}")

    # 1. RawTherapee (HTTP Range 按需提取 18 个 PNG + README.txt)
    print("\n[1/6] 正在从 RawTherapee 官方仓库提取 18 款经典胶片与拍立得预设...")
    zf_rt, buf_rt, ranged_rt = open_remote_zip(URL_RAWTHERAPEE_ZIP)
    try:
        print(f"  （读取方式：{'HTTP Range 按需分片' if ranged_rt else '完整下载'}）")
        rt_by_path = {n: n for n in zf_rt.namelist()}
        for rel, src_path in RAWTHERAPEE_ITEMS:
            if src_path not in rt_by_path:
                raise KeyError(f"RawTherapee ZIP 中找不到 {src_path}")
            record(rel, zf_rt.read(src_path), validate_png)
        if "HaldCLUT/README.txt" in rt_by_path:
            write_target_file(dest_root, "README.txt", zf_rt.read("HaldCLUT/README.txt"), overwrite=True)
    finally:
        zf_rt.close()
        if buf_rt:
            buf_rt.close()

    # 2. Stuart Sowerby Fujifilm X-Trans III
    print("\n[2/6] 正在获取 Stuart Sowerby 富士 X-Trans III 模拟（5 款）...")
    zf_sw, buf_sw, ranged_sw = open_remote_zip(URL_SOWERBY_ZIP)
    try:
        print(f"  （读取方式：{'HTTP Range 按需分片' if ranged_sw else '完整下载'}）")
        sw_by_base = {n.rsplit("/", 1)[-1]: n for n in zf_sw.namelist() if n.lower().endswith(".png")}
        for rel, base_name in SOWERBY_ITEMS:
            if base_name not in sw_by_base:
                raise KeyError(f"Sowerby ZIP 中找不到 {base_name}")
            record(rel, zf_sw.read(sw_by_base[base_name]), validate_png)
    finally:
        zf_sw.close()
        if buf_sw:
            buf_sw.close()

    # 3. abpy Fujifilm X-Trans IV (Provia -> sRGB LUTs)
    print("\n[3/6] 正在获取 abpy 富士 X-Trans IV 模拟（Classic / Nostalgic Neg / Bleach Bypass）...")
    for rel, encoded_name in ABPY_ITEMS:
        data = download_bytes(URL_ABPY_BASE + encoded_name)
        record(rel, data, validate_cube_bytes)

    # 4. imnz730 Kodak 2383 / Fujifilm 3513DI（现场烘焙 sRGB -> Linear -> Cineon Log 适配版）
    print("\n[4/6] 正在下载并烘焙 sRGB 适配版 Kodak 2383 & Fujifilm 3513DI...")
    s2l_text = download_bytes(URL_IMNZ_BASE + "VFX%20IO/sRGB%20to%20Linear.cube").decode("utf-8", errors="replace")
    l2c_text = download_bytes(URL_IMNZ_BASE + "VFX%20IO/Linear%20to%20Cineon%20Log.cube").decode("utf-8", errors="replace")
    s2l = parse_cube_1d(s2l_text, "sRGB to Linear.cube")
    l2c = parse_cube_1d(l2c_text, "Linear to Cineon Log.cube")

    for src_sub, out_rel, title in [
        ("Film%20Looks/Rec709%20Kodak%202383%20D65.cube", "03_电影感与印片/Kodak 2383 D65 (sRGB适配).cube", "Kodak 2383 D65 (sRGB adapted)"),
        ("Film%20Looks/Rec709%20Fujifilm%203513DI%20D65.cube", "03_电影感与印片/Fujifilm 3513DI D65 (sRGB适配).cube", "Fujifilm 3513DI D65 (sRGB adapted)"),
    ]:
        film_text = download_bytes(URL_IMNZ_BASE + src_sub).decode("utf-8", errors="replace")
        baked = bake_srgb_cineon_film(s2l, l2c, film_text, title, out_n=33)
        record(out_rel, baked, validate_cube_bytes)

    # 5. PictureFX
    print("\n[5/6] 正在获取 PictureFX GoldFX Spring Breeze 与 CineStill 800T v2...")
    record("01_日常与经典胶片/PictureFX GoldFX Spring Breeze.png", download_bytes(URL_PICTUREFX_SPRING), validate_png)
    record("03_电影感与印片/PictureFX CineStill 800T v2.cube", download_bytes(URL_PICTUREFX_800T), validate_cube_bytes)

    # 6. IWLTBAP Freeware (4 款，不随包分发，仅用户主动从官方实时获取)
    if args.skip_iwltbap:
        print("\n[6/6] 已指定 --skip-iwltbap，跳过 IWLTBAP 预设。")
    else:
        print("\n[6/6] 正在从 IWLTBAP 官网提取 4 款免费电影质感 LUT...")
        zf_iw, buf_iw, ranged_iw = open_remote_zip(URL_IWLTBAP_ZIP)
        try:
            print(f"  （读取方式：{'HTTP Range 按需分片' if ranged_iw else '完整下载'}）")
            all_names = zf_iw.namelist()
            for rel, suffix in IWLTBAP_ITEMS:
                matched = [n for n in all_names if n.endswith(suffix)]
                if not matched:
                    raise KeyError(f"IWLTBAP ZIP 中找不到后缀 {suffix}")
                record(rel, zf_iw.read(matched[0]), validate_cube_bytes)
        finally:
            zf_iw.close()
            if buf_iw:
                buf_iw.close()

    write_licenses_notice(dest_root, include_iwltbap=not args.skip_iwltbap)

    # 校验本包应安装的条目全部就绪，并统计当前目录总 LUT 数与重复情况
    missing = [r for r in expected_rel_paths(args.skip_iwltbap) if not os.path.isfile(os.path.join(dest_root, r))]
    total_found = 0
    md5_map: Dict[str, List[str]] = {}
    for dp, _, fns in os.walk(dest_root):
        for fn in sorted(fns):
            if not fn.startswith(".") and fn.lower().endswith((".png", ".tif", ".tiff", ".cube")):
                p = os.path.join(dp, fn)
                total_found += 1
                with open(p, "rb") as f:
                    h = hashlib.md5(f.read()).hexdigest()
                md5_map.setdefault(h, []).append(os.path.relpath(p, dest_root))
    dup_count = sum(1 for v in md5_map.values() if len(v) > 1)

    print("\n==========================================")
    if missing:
        print(f"警告：以下 {len(missing)} 个条目未就绪：")
        for m in missing:
            print("  -", m)
        return 1

    print(f"安装完成！本次写入 {stats['written']} 个、跳过已有 {stats['skipped']} 个。")
    print(f"当前目标目录共有 {total_found} 个可用 LUT（内容重复组：{dup_count}）。")
    if backup_dir:
        print(f"旧目录已安全备份于：{backup_dir}")
    print("\n下一步：打开 Phos，在右侧面板「色彩 → 胶片 CLUT」中点「刷新」，即可看到完整分类列表。")
    print("==========================================")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已取消安装。")
        sys.exit(130)
    except urllib.error.URLError as err:
        print(f"\n网络访问失败：{err}")
        print("请确认本机可以访问 GitHub / RawTherapee / IWLTBAP，或配置代理后重试。")
        sys.exit(1)
    except Exception as err:
        print(f"\n安装出错：{err}")
        sys.exit(1)
