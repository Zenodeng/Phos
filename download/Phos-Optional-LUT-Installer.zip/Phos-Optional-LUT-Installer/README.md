# Phos 可选精选胶片 LUT 安装包

Phos 主程序刻意保持轻量，默认不打包数十兆乃至数百兆的第三方 LUT 文件。
如果你需要一组**精选无重复、全部可直接用于 sRGB / Rec.709 照片（开箱即出片，不偏灰不死黑）**的胶片模拟，双击本包里的脚本即可自动安装到 Phos 默认扫描目录 `~/Documents/RawTherapee/HaldCLUT`。

## 为什么做这个精选包

1. RawTherapee 官方整包有 300 多个文件（约 421 MB），包含大量 `++` / `--` 档位和已停产杂项，翻找很慢。本安装器通过 HTTP 分片按需提取其中的经典款，只产生约 30–40 MB 流量。
2. 网上流行的 Kodak 2383 / 富士 X-Trans IV 很多 LUT 原件是 **Cineon Log** 或 **线性输入**，直接套在 sRGB 照片上会严重压暗或爆亮；本脚本会在本机自动用 1D 曲线转换并烘焙 `sRGB -> Linear -> Cineon Log -> Film Print`（Kodak 2383 D65 / Fujifilm 3513DI D65），并选用 `Provia to ... sRGB.cube` 版本，保证打开即用。
3. 所有文件都不随安装包再分发，安装时从各自原作者的官方公开地址拉取，避免把非 MIT 授权（`CC BY-SA 4.0` / `CC BY-NC-SA 4.0` / 禁止二次分发的免费商用 LUT）混入 Phos 安装包。

## 安装目录结构（共 34 款）

安装后会按场景分进 5 个干净文件夹：

- `常用推荐/`（8 款）：`Kodak Portra 400 2`、`Kodak Ektar 100`、`Kodak Kodachrome 64`、`Fuji 400H 2`、`Fuji Superia 400 2`、`Agfa Vista 200`、`Ilford HP5 2`、`Kodak T-Max 400`
- `01_日常与经典胶片/`（6 款）：`Kodak Portra 160 2`、`Portra 400 NC 2`、`Portra 800 2`、`Fuji Provia 100F`、`Fuji Velvia 50`、`PictureFX GoldFX Spring Breeze`
- `02_富士模拟/`（8 款）：Stuart Sowerby X-Trans III（`Classic Chrome`、`Pro Neg Hi`、`Velvia`、`Acros`、`Acros+Ye`）+ abpy X-Trans IV sRGB 转换（`Classic Neg`、`Nostalgic Neg`、`Bleach Bypass`）
- `03_电影感与印片/`（10 款）：`Kodak 2383 D65 (sRGB适配)`、`Fujifilm 3513DI D65 (sRGB适配)`、`PictureFX CineStill 800T v2`、`IWLTBAP` 免费包 4 款（`F-8700-V2-STD` / `Aspen` / `Sedona` / `Humble`）、`TealOrange2`、`BleachBypass2`、`DropBlues`
- `04_拍立得复古/`（2 款）：`Polaroid 690 3`、`Polaroid PX-70 3`

## 使用方法

1. 解压本压缩包到任意文件夹。
2. **双击「`安装精选胶片LUT.command`」**（如果系统拦截未签名脚本，右键点它选择「打开」，或在「系统设置 → 隐私与安全性」点「仍要打开」）。
3. 若你原本 `~/Documents/RawTherapee/HaldCLUT` 里已经有文件，脚本会先询问：
   - 选 `1`：把旧目录整体移至同级 `HaldCLUT_备份_<时间戳>` 留底（若原有 `我的LUT` 会自动保留回来），再装入整洁分类；
   - 选 `2`（默认）：不改旧目录，只补充写入缺少的精选 LUT。
4. 完成后打开 Phos，在右侧检查器 **「色彩 → 胶片 CLUT」** 中点 **「刷新」**，新分类就会立刻出现。

## 命令行可选参数（面向进阶用户）

```bash
python3 install_luts.py --help
python3 install_luts.py --mode merge            # 保留旧目录，仅补充缺少项
python3 install_luts.py --mode clean            # 备份旧目录后干净重装
python3 install_luts.py --skip-iwltbap          # 跳过 IWLTBAP（仅装 30 款开源/社区预设）
python3 install_luts.py --dest /custom/path     # 安装到指定目录
```

---

English quick note: This optional installer fetches 34 curated sRGB/Rec.709-ready LUTs directly from their original upstream sources (RawTherapee HaldCLUT, Stuart Sowerby, abpy, imnz730 with live sRGB-to-Cineon baking, PictureFX, and IWLTBAP Freeware) using standard-library Python 3 and places them into `~/Documents/RawTherapee/HaldCLUT`. Inspect `LICENSE-THIRD-PARTY.md` for per-source terms (`abpy` is `CC BY-NC-SA 4.0` non-commercial; `IWLTBAP` LUT files may not be redistributed).
